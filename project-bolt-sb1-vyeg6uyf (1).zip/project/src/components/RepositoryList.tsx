import React from 'react';
import { Book } from 'lucide-react';
import type { Repository } from '../types';

interface RepositoryListProps {
  repositories: Repository[];
  onSelectRepo: (repo: Repository) => void;
}

export function RepositoryList({ repositories, onSelectRepo }: RepositoryListProps) {
  return (
    <div className="space-y-4">
      {repositories.map((repo) => (
        <div
          key={repo.id}
          onClick={() => onSelectRepo(repo)}
          className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="flex items-start space-x-3">
            <Book className="w-5 h-5 text-gray-600 mt-1" />
            <div>
              <h3 className="text-xl font-semibold text-blue-600">{repo.name}</h3>
              {repo.description && (
                <p className="text-gray-600 mt-1">{repo.description}</p>
              )}
              <p className="text-sm text-gray-500 mt-2">
                Created on {repo.createdAt.toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}