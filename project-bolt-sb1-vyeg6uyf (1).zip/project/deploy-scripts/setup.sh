#!/bin/bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Node.js and npm
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install Nginx
sudo apt install -y nginx

# Create nginx configuration
sudo tee /etc/nginx/sites-available/repository-manager <<EOF
server {
    listen 80;
    server_name your-domain.com;  # Replace with your domain
    root /var/www/repository-manager;
    index index.html;

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF

# Enable the site
sudo ln -s /etc/nginx/sites-available/repository-manager /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Create deployment directory
sudo mkdir -p /var/www/repository-manager
sudo chown -R $USER:$USER /var/www/repository-manager