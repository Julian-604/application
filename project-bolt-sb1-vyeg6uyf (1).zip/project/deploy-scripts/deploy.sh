#!/bin/bash
# Build the application
npm run build

# Copy build files to nginx directory
sudo cp -r dist/* /var/www/repository-manager/

# Restart nginx
sudo systemctl restart nginx