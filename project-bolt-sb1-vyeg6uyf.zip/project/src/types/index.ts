export interface Repository {
  id: string;
  name: string;
  description: string;
  createdAt: Date;
  files: File[];
}

export interface File {
  id: string;
  name: string;
  content: string;
  createdAt: Date;
}