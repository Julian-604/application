import React, { useState } from 'react';
import { FilePlus } from 'lucide-react';
import type { Repository, File } from '../types';

interface RepositoryViewProps {
  repository: Repository;
  onCreateFile: (repoId: string, fileName: string, content: string) => void;
}

export function RepositoryView({ repository, onCreateFile }: RepositoryViewProps) {
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [fileName, setFileName] = useState('');
  const [fileContent, setFileContent] = useState('');

  const handleCreateFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (fileName.trim() && fileContent.trim()) {
      onCreateFile(repository.id, fileName, fileContent);
      setFileName('');
      setFileContent('');
      setIsCreatingFile(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">{repository.name}</h2>
          {repository.description && (
            <p className="text-gray-600 mt-1">{repository.description}</p>
          )}
        </div>
        <button
          onClick={() => setIsCreatingFile(true)}
          className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          <FilePlus className="w-5 h-5" />
          <span>Add file</span>
        </button>
      </div>

      {isCreatingFile && (
        <form onSubmit={handleCreateFile} className="mb-8 bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-4">Create new file</h3>
          <div className="space-y-4">
            <div>
              <label htmlFor="fileName" className="block text-sm font-medium text-gray-700">
                File name *
              </label>
              <input
                type="text"
                id="fileName"
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                Content *
              </label>
              <textarea
                id="content"
                value={fileContent}
                onChange={(e) => setFileContent(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 font-mono"
                rows={8}
                required
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setIsCreatingFile(false)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
              >
                Create file
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="border rounded-lg divide-y">
        {repository.files.map((file: File) => (
          <div key={file.id} className="p-4 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{file.name}</h3>
              <span className="text-sm text-gray-500">
                Created on {file.createdAt.toLocaleDateString()}
              </span>
            </div>
            <pre className="mt-4 p-4 bg-gray-50 rounded-md overflow-x-auto">
              <code>{file.content}</code>
            </pre>
          </div>
        ))}
        {repository.files.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            No files in this repository yet
          </div>
        )}
      </div>
    </div>
  );
}