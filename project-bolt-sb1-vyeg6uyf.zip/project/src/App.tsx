import React, { useState } from 'react';
import { Header } from './components/Header';
import { CreateRepository } from './components/CreateRepository';
import { RepositoryList } from './components/RepositoryList';
import { RepositoryView } from './components/RepositoryView';
import type { Repository } from './types';

function App() {
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<Repository | null>(null);

  const handleCreateRepo = (name: string, description: string) => {
    const newRepo: Repository = {
      id: crypto.randomUUID(),
      name,
      description,
      createdAt: new Date(),
      files: [],
    };
    setRepositories([...repositories, newRepo]);
  };

  const handleCreateFile = (repoId: string, fileName: string, content: string) => {
    setRepositories(repositories.map(repo => {
      if (repo.id === repoId) {
        return {
          ...repo,
          files: [...repo.files, {
            id: crypto.randomUUID(),
            name: fileName,
            content,
            createdAt: new Date(),
          }],
        };
      }
      return repo;
    }));

    // Update selected repo if it's the current one
    if (selectedRepo?.id === repoId) {
      const updatedRepo = repositories.find(r => r.id === repoId);
      if (updatedRepo) {
        setSelectedRepo(updatedRepo);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <CreateRepository onCreateRepo={handleCreateRepo} />
        
        {selectedRepo ? (
          <div className="space-y-4">
            <button
              onClick={() => setSelectedRepo(null)}
              className="text-blue-600 hover:text-blue-800"
            >
              ← Back to repositories
            </button>
            <RepositoryView
              repository={selectedRepo}
              onCreateFile={handleCreateFile}
            />
          </div>
        ) : (
          <div>
            <h2 className="text-2xl font-bold mb-6">Your Repositories</h2>
            {repositories.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <p className="text-gray-500">No repositories yet. Create your first one!</p>
              </div>
            ) : (
              <RepositoryList
                repositories={repositories}
                onSelectRepo={setSelectedRepo}
              />
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;